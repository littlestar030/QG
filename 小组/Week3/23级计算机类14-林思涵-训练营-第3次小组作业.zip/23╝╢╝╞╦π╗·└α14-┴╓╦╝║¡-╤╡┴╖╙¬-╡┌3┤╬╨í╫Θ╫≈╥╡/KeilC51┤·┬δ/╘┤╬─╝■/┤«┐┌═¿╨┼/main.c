#include "reg51.h"
#include "intrins.h"

typedef unsigned char BYTE;
typedef unsigned int WORD;

#define FOSC 11059200L      //System frequency
#define BAUD 9600           //UART baudrate

bit busy;

void SendData(BYTE dat);
void SendString(char *s);
void Delay(unsigned int xms);

void main()
{
    SCON = 0x50;            //8-bit variable UART

    TMOD = 0x20;            //Set Timer1 as 8-bit auto reload mode
    TH1 = TL1 = -(FOSC/12/32/BAUD); //Set auto-reload vaule
    TR1 = 1;                //Timer1 start run
    ES = 1;                 //Enable UART interrupt
    EA = 1;                 //Open master interrupt switch
	while(1)
	{
		SendString("helloworld\n");
		Delay(1000);
	}
}

/*----------------------------
UART interrupt service routine
----------------------------*/
void Uart_Isr() interrupt 4
{
	unsigned char res=0;
    if (RI)
    {
        RI = 0;             //Clear receive interrupt flag
        res = SBUF;          //P0 show UART data
		SBUF=res;
	}	
    if (TI)
    {
        TI = 0;             //Clear transmit interrupt flag
        busy = 0;           //Clear transmit busy flag
    }
}

/*----------------------------
Send a byte data to UART
Input: dat (data to be sent)
Output:None
----------------------------*/
void SendData(BYTE dat)
{
    while (busy);           //Wait for the completion of the previous data is sent
    busy = 1;
    SBUF = dat;             //Send data to UART buffer
}

/*----------------------------
Send a string to UART
Input: s (address of string)
Output:None
----------------------------*/
void SendString(char *s)
{
    while (*s)              //Check the end of the string
    {
        SendData(*s++);     //Send current char and increment string ptr
    }
}

void Delay(unsigned int xms)
{
	unsigned char data i, j;
	while(xms--)
	{
					i = 2;
			j = 239;
			do
			{
				while (--j);
			} while (--i);
	}
}