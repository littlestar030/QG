#ifndef __TEST_H_
#define _TEST_H_

void generate_data(int size,int max,int min);
void test_big(int* data_sizes, int sizes_count);
void test_small(int data_size, int repetitions);
void read_data(int* a, int size, int max, int min);
void Sort();
void Print(int* a, int size);
#endif
