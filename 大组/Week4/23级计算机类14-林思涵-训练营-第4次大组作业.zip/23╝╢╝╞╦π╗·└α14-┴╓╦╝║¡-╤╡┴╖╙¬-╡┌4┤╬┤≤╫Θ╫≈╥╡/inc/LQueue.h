#ifndef LQUEUE_H_INCLUDED
#define LQUEUE_H_INCLUDED
#include "binary_sort_tree.h"
//��ʽ���нṹ
typedef struct lnode
{
    NodePtr data;
    struct lnode* next;            //ָ��ǰ������һ���
} LNode;

typedef struct Lqueue
{
    LNode* front;                   //��ͷ
    LNode* rear;                    //��β
    size_t length;            //���г���
} LQueue;

//char type;
//char datatype[30];

void InitLQueue(LQueue* Q);
void DestoryLQueue(LQueue* Q);
Status IsEmptyLQueue(const LQueue* Q);
//Status GetHeadLQueue(LQueue* Q, void* e);
int LengthLQueue(LQueue* Q);
Status EnLQueue(LQueue* Q, NodePtr data);
NodePtr DeLQueue(LQueue* Q);
void ClearLQueue(LQueue* Q);
//Status TraverseLQueue(const LQueue* Q, void (*foo)(void* q));
//void LPrint(void* q);

#endif // LQUEUE_H_INCLUDED
