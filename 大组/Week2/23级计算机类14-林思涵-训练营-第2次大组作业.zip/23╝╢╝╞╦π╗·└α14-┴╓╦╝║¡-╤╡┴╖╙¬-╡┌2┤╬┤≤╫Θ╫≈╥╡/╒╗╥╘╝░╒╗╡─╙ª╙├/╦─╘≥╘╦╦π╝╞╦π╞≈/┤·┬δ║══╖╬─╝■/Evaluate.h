#ifndef __EVALUATE_H_
#define __EVALUATE_H_
#include "LinkStack.h"

extern LinkStack* s;
int Evaluate(LinkStack* s,char* expression);
void Change(char* expression);

#endif
